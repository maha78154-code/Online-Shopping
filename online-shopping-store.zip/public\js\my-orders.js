// NovaMarket - Customer Orders Controller

let customerOrders = [];

document.addEventListener('DOMContentLoaded', async () => {
  const user = getUser();
  const token = getToken();

  if (!user || !token) {
    showToast('Please sign in to view your orders.', 'info');
    setTimeout(() => {
      window.location.href = 'login.html?redirect=my-orders.html';
    }, 800);
    return;
  }

  const greeting = document.getElementById('user-greeting');
  if (greeting) {
    greeting.innerText = `Welcome back, ${user.name}!`;
  }

  await loadCustomerOrders();
});

async function loadCustomerOrders() {
  const container = document.getElementById('orders-list-container');
  if (!container) return;

  container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-muted);">Loading your order history...</div>';

  try {
    const token = getToken();
    const res = await fetch('/api/orders/my', {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await res.json();

    if (res.ok && data.success) {
      customerOrders = data.orders;
      renderOrdersList(customerOrders);
    } else {
      container.innerHTML = `<div style="text-align: center; color: var(--danger);">${data.message || 'Failed to load orders.'}</div>`;
    }
  } catch (err) {
    container.innerHTML = '<div style="text-align: center; color: var(--danger);">Network error. Please try again.</div>';
  }
}

function renderOrdersList(orders) {
  const container = document.getElementById('orders-list-container');
  if (!container) return;

  if (orders.length === 0) {
    container.innerHTML = `
      <div style="background: #fff; border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 60px 20px; text-align: center;">
        <div style="font-size: 44px; margin-bottom: 12px;">📦</div>
        <h3 style="font-size: 20px; font-weight: 700; margin-bottom: 8px;">No orders found yet</h3>
        <p style="color: var(--text-muted); margin-bottom: 24px;">When you purchase items, your delivery tracking will appear here.</p>
        <a href="products.html" class="btn btn-primary">Start Shopping</a>
      </div>
    `;
    return;
  }

  container.innerHTML = orders.map(o => {
    const canCancel = (o.status === 'pending' || o.status === 'processing');

    const itemsHtml = (o.items || []).map(it => `
      <div style="display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border-light); font-size: 14px;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <img src="${it.product_image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=100&q=80'}" style="width: 48px; height: 48px; object-fit: cover; border-radius: var(--radius-sm); border: 1px solid var(--border);">
          <div>
            <strong>${it.product_name}</strong>
            <div style="font-size: 12px; color: var(--text-muted);">Qty: ${it.quantity} × ${formatCurrency(it.price)}</div>
          </div>
        </div>
        <strong>${formatCurrency(it.total)}</strong>
      </div>
    `).join('');

    return `
      <div style="background: #fff; border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 24px; margin-bottom: 24px; box-shadow: var(--shadow-sm);">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 16px; padding-bottom: 14px; border-bottom: 1px solid var(--border);">
          <div>
            <span class="badge badge-${o.status}">${o.status}</span>
            <span style="font-size: 15px; font-weight: 800; color: var(--dark); margin-left: 8px;">Order #${o.order_number}</span>
            <span style="font-size: 13px; color: var(--text-muted); margin-left: 8px;">Placed on ${new Date(o.created_at).toLocaleDateString()}</span>
          </div>

          <div style="font-size: 20px; font-weight: 800; color: var(--primary);">
            ${formatCurrency(o.total_amount)}
          </div>
        </div>

        <!-- Items list -->
        <div style="margin-bottom: 16px;">
          ${itemsHtml}
        </div>

        <!-- Shipping & Footer Info -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 14px; background: var(--bg-subtle); padding: 14px; border-radius: var(--radius-md); font-size: 13px;">
          <div>
            <div style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; font-weight: 700;">Shipping Address</div>
            <div>${o.shipping_address}</div>
            <div style="color: var(--text-muted); margin-top: 2px;">Paid via: ${o.payment_method}</div>
          </div>

          <div>
            ${canCancel ? `
              <button onclick="cancelOrder(${o.id})" class="btn btn-secondary btn-sm" style="color: var(--danger); border-color: #fecaca;">
                Cancel Order
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

async function cancelOrder(orderId) {
  if (!confirm('Are you sure you want to cancel this order? Items will be returned to inventory.')) return;

  const token = getToken();
  try {
    const res = await fetch(`/api/orders/${orderId}/cancel`, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('Order has been cancelled.', 'info');
      await loadCustomerOrders();
    } else {
      showToast(data.message || 'Failed to cancel order.', 'error');
    }
  } catch (err) {
    showToast('Failed to connect to server.', 'error');
  }
}
