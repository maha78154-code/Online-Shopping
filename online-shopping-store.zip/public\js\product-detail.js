// NovaMarket - Product Detail Controller

let currentProduct = null;
let currentQuantity = 1;

document.addEventListener('DOMContentLoaded', async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');

  if (!productId) {
    window.location.href = 'products.html';
    return;
  }

  await loadProductDetails(productId);
});

async function loadProductDetails(id) {
  try {
    const res = await fetch(`/api/products/${id}`);
    const data = await res.json();

    if (!res.ok || !data.success || !data.product) {
      document.getElementById('product-detail-container').innerHTML = `
        <div style="text-align: center; padding: 80px 20px;">
          <h2>Product Not Found</h2>
          <p style="color: var(--text-muted); margin: 10px 0 20px;">The product you are looking for has been moved or retired.</p>
          <a href="products.html" class="btn btn-primary">Return to Catalog</a>
        </div>
      `;
      return;
    }

    currentProduct = data.product;
    renderProductPage(data.product, data.reviews, data.relatedProducts);
  } catch (err) {
    console.error('Error loading product details:', err);
  }
}

function renderProductPage(product, reviews = [], related = []) {
  document.title = `${product.name} | NovaMarket`;

  // Breadcrumbs
  document.getElementById('breadcrumb-category').innerText = product.category_name || 'Shop';
  document.getElementById('breadcrumb-category').href = `products.html?category=${product.category_slug || ''}`;
  document.getElementById('breadcrumb-title').innerText = product.name;

  // Main Image
  document.getElementById('product-main-img').src = product.image_url;
  document.getElementById('product-main-img').alt = product.name;

  // Info
  document.getElementById('product-name').innerText = product.name;
  document.getElementById('product-category-tag').innerText = product.category_name || 'Item';
  document.getElementById('product-price').innerText = formatCurrency(product.price);

  if (product.original_price) {
    document.getElementById('product-original-price').innerText = formatCurrency(product.original_price);
    const discount = Math.round(((product.original_price - product.price) / product.original_price) * 100);
    document.getElementById('product-discount-pill').innerText = `Save ${discount}%`;
    document.getElementById('product-discount-pill').style.display = 'inline-block';
  } else {
    document.getElementById('product-discount-pill').style.display = 'none';
  }

  // Rating
  document.getElementById('product-rating-stars').innerText = `★ ${product.rating}`;
  document.getElementById('product-rating-count').innerText = `(${product.reviews_count || reviews.length} customer reviews)`;

  // Stock
  const stockEl = document.getElementById('product-stock-badge');
  if (product.stock > 0) {
    stockEl.innerHTML = `<span style="color: var(--success);">● In Stock (${product.stock} units available)</span>`;
  } else {
    stockEl.innerHTML = `<span style="color: var(--danger);">● Out of Stock</span>`;
    document.getElementById('btn-add-to-cart').disabled = true;
    document.getElementById('btn-buy-now').disabled = true;
  }

  // Description
  document.getElementById('product-description').innerText = product.description;

  // Reviews list
  renderReviews(reviews, product.id);

  // Related products
  renderRelatedProducts(related);
}

function adjustQuantity(delta) {
  if (!currentProduct) return;
  const newQty = currentQuantity + delta;
  if (newQty >= 1 && newQty <= (currentProduct.stock || 99)) {
    currentQuantity = newQty;
    document.getElementById('qty-display').innerText = currentQuantity;
  }
}

function handleAddToCartFromDetail() {
  if (!currentProduct) return;
  addToCart(currentProduct, currentQuantity);
}

function handleBuyNowFromDetail() {
  if (!currentProduct) return;
  addToCart(currentProduct, currentQuantity);
  window.location.href = 'checkout.html';
}

function renderReviews(reviews, productId) {
  const container = document.getElementById('reviews-list');
  if (!container) return;

  if (reviews.length === 0) {
    container.innerHTML = '<p style="color: var(--text-muted); font-style: italic;">No reviews yet. Be the first to share your thoughts!</p>';
    return;
  }

  container.innerHTML = reviews.map(r => `
    <div style="border-bottom: 1px solid var(--border-light); padding: 16px 0;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
        <strong style="color: var(--dark); font-size: 14px;">${r.customer_name}</strong>
        <span style="color: #f59e0b; font-size: 14px;">${'★'.repeat(r.rating)}</span>
      </div>
      <p style="font-size: 14px; color: var(--text-main); margin-bottom: 4px;">${r.comment}</p>
      <span style="font-size: 12px; color: var(--text-light);">${new Date(r.created_at).toLocaleDateString()}</span>
    </div>
  `).join('');
}

async function handleReviewSubmit(e) {
  e.preventDefault();
  const user = getUser();
  const token = getToken();

  if (!user || !token) {
    showToast('Please log in to leave a review.', 'info');
    setTimeout(() => {
      window.location.href = `login.html?redirect=${encodeURIComponent(window.location.href)}`;
    }, 1000);
    return;
  }

  const rating = document.getElementById('review-rating-select').value;
  const comment = document.getElementById('review-comment-input').value.trim();

  try {
    const res = await fetch(`/api/products/${currentProduct.id}/reviews`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ rating, comment })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('Thank you for your feedback! Review posted.', 'success');
      document.getElementById('review-comment-input').value = '';
      await loadProductDetails(currentProduct.id);
    } else {
      showToast(data.message || 'Failed to submit review.', 'error');
    }
  } catch (err) {
    showToast('Network error.', 'error');
  }
}

function renderRelatedProducts(products) {
  const grid = document.getElementById('related-products-grid');
  if (!grid || !products || products.length === 0) return;

  grid.innerHTML = products.map(p => `
    <div class="product-card">
      <div class="product-img-wrap" style="height: 180px;">
        <a href="product-detail.html?id=${p.id}" style="width: 100%; height: 100%;">
          <img src="${p.image_url}" alt="${p.name}" class="product-img">
        </a>
      </div>
      <div class="product-body" style="padding: 14px;">
        <h4 style="font-size: 14px; margin-bottom: 6px;">
          <a href="product-detail.html?id=${p.id}">${p.name}</a>
        </h4>
        <div style="font-weight: 700; color: var(--dark); font-size: 16px;">${formatCurrency(p.price)}</div>
      </div>
    </div>
  `).join('');
}
