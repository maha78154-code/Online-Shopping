# 🛍️ NovaMarket - Full-Stack Online Shopping & E-Commerce Web Application

A full-stack, responsive multi-page e-commerce shopping platform built with **Node.js, Express, and SQLite**, complete with persistent cart management, user authentication, customer orders tracking, and an administrative store control dashboard.

---

## 🌟 Key Features

### 🛒 Customer Storefront
- **Home Portal (`index.html`)**: Trending items, flash promo banner, product categories, editorial selections, value proposition badges (*Free Shipping, 30-Day Returns, 24/7 Support*), and newsletter subscription.
- **Product Catalog (`products.html`)**: Real-time category filtering (*Electronics, Fashion, Home, Beauty, Accessories*), keyword search, price range filter ($ min - max), and sorting (*Featured, Low-to-High, High-to-Low, Top Rated, Newest*).
- **Product Detail View (`product-detail.html`)**: Dynamic image display, stock availability status, quantity selector, *"Add to Cart"* and *"Buy Now"* triggers, customer reviews, review submission form, and related product recommendations.
- **Shopping Cart (`cart.html`)**: Live quantity adjustment, item removal, line-item totals, promo coupon discount (*code: `SAVE20` for 20% off*), sales tax calculation (8%), and free shipping threshold calculation.
- **Checkout (`checkout.html`)**: Shipping and delivery contact address form, payment method selector (*Credit Card, PayPal, Cash on Delivery*), and order review summary.
- **Order Confirmation (`order-confirmation.html`)**: Dedicated receipt page with unique reference `#ORD-XXXXXX` and estimated delivery dates.
- **Customer Dashboard (`my-orders.html`)**: Real-time tracking of order packages (*Processing, Shipped, Delivered, Cancelled*), purchased product thumbnails, and order cancellation.
- **Authentication (`login.html` & `register.html`)**:
  - Secure bcrypt password hashing & JWT token sessions.
  - **1-Click Demo Fill buttons** for effortless customer and admin testing.

### 👑 Administrative Management (`admin.html`)
- **Store Analytics & KPIs**:
  - Total Sales Revenue ($ from non-cancelled orders)
  - Total Orders Count
  - Total Active Products
  - Total Registered Customers
  - Top Selling Products breakdown
  - Low Stock Inventory Alerts
- **Order Management Table**:
  - Live search by order number, customer name, or email.
  - Filter by order status.
  - Status updater dropdown (*Processing* → *Shipped* → *Delivered* → *Cancelled*).
- **Product Inventory Management**:
  - Full product table with stock counts and pricing.
  - **Add New Product Modal**: Insert products with images, categories, prices, and stock directly into the SQLite database.
  - Delete product action.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3 (Modern responsive design system), Vanilla JavaScript (ES6+ Fetch API, DOM manipulation, LocalStorage Cart).
- **Backend**: Node.js, Express.js.
- **Database**: SQLite (via `sqlite3`, persistent database file `database/store.sqlite` with automatic schema creation and initial seeding).
- **Security**: `bcryptjs` (password encryption), `jsonwebtoken` (JWT bearer authentication).

---

## 🔑 Demo Login Accounts

Pre-seeded into the SQLite database:

| Role | Email | Password | Access Rights |
| :--- | :--- | :--- | :--- |
| **Customer** | `customer@gmail.com` | `customer123` | Cart, checkout, personal orders & cancellation |
| **Admin** | `admin@store.com` | `admin123` | Sales KPIs, order status controller & product inventory |

*(You can also use the **"Fill Customer"** or **"Fill Admin"** buttons on `login.html`)*

---

## 🚀 How to Execute in VS Code

### Step 1: Open the Project in VS Code
1. Open **VS Code**.
2. Click **File** → **Open Folder...**
3. Select this folder:
   ```
   C:\Users\HP\.gemini\antigravity\scratch\online-shopping-store
   ```

### Step 2: Open Terminal
Press **`` Ctrl + ` ``** (backtick) or select **Terminal** → **New Terminal**.

### Step 3: Install Dependencies
Run:
```powershell
npm.cmd install
```
*(or `npm install`)*

### Step 4: Start the Server
Run:
```powershell
npm.cmd start
```
*(or `npm start`)*

*Console Output:*
```text
====================================================
   🛍️  NovaMarket E-Commerce Store Online 🛍️        
   Store URL:    http://localhost:5000
   Admin Portal: http://localhost:5000/admin.html
   Customer:     customer@gmail.com / customer123
   Admin:        admin@store.com / admin123
====================================================
```

*(Convenience Shortcut: You can also simply double-click **`start.bat`** in the project folder to install dependencies and run the server automatically!)*

### Step 5: Open in Your Browser
- Visit: **[http://localhost:5000](http://localhost:5000)**
