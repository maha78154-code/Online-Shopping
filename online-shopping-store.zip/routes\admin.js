const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAdmin } = require('../middleware/auth');

// GET /api/admin/stats
router.get('/stats', requireAdmin, async (req, res) => {
  try {
    // 1. Total Revenue
    const revenueRow = await db.get(
      `SELECT SUM(total_amount) AS revenue FROM orders WHERE status != 'cancelled'`
    );
    const totalRevenue = revenueRow.revenue || 0;

    // 2. Total Orders
    const ordersRow = await db.get('SELECT COUNT(*) AS total FROM orders');
    const totalOrders = ordersRow.total || 0;

    // 3. Status breakdown
    const pendingOrders = await db.get(`SELECT COUNT(*) AS count FROM orders WHERE status = 'pending'`);
    const processingOrders = await db.get(`SELECT COUNT(*) AS count FROM orders WHERE status = 'processing'`);
    const shippedOrders = await db.get(`SELECT COUNT(*) AS count FROM orders WHERE status = 'shipped'`);
    const deliveredOrders = await db.get(`SELECT COUNT(*) AS count FROM orders WHERE status = 'delivered'`);
    const cancelledOrders = await db.get(`SELECT COUNT(*) AS count FROM orders WHERE status = 'cancelled'`);

    // 4. Total Products & Total Customers
    const productsRow = await db.get('SELECT COUNT(*) AS total FROM products');
    const customersRow = await db.get(`SELECT COUNT(*) AS total FROM users WHERE role = 'customer'`);

    // 5. Low stock alerts
    const lowStock = await db.all('SELECT id, name, stock, price FROM products WHERE stock <= 10 ORDER BY stock ASC');

    // 6. Recent Orders
    const recentOrders = await db.all(
      `SELECT id, order_number, customer_name, total_amount, status, created_at 
       FROM orders 
       ORDER BY created_at DESC 
       LIMIT 5`
    );

    // 7. Top Selling Products
    const topProducts = await db.all(
      `SELECT product_name, SUM(quantity) as units_sold, SUM(total) as sales_revenue
       FROM order_items
       GROUP BY product_id
       ORDER BY units_sold DESC
       LIMIT 4`
    );

    res.json({
      success: true,
      stats: {
        totalRevenue,
        totalOrders,
        pendingCount: pendingOrders.count || 0,
        processingCount: processingOrders.count || 0,
        shippedCount: shippedOrders.count || 0,
        deliveredCount: deliveredOrders.count || 0,
        cancelledCount: cancelledOrders.count || 0,
        totalProducts: productsRow.total || 0,
        totalCustomers: customersRow.total || 0,
        lowStock,
        recentOrders,
        topProducts
      }
    });
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve admin stats.' });
  }
});

module.exports = router;
