const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// Helper to generate unique order number
function generateOrderNumber() {
  const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let code = 'ORD-';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// POST /api/orders (Place Order - Requires Auth)
router.post('/', requireAuth, async (req, res) => {
  try {
    const { items, customer_name, customer_email, customer_phone, shipping_address, payment_method, notes } = req.body;
    const userId = req.user.id;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'Your shopping cart is empty.' });
    }

    if (!shipping_address || !customer_name || !customer_email) {
      return res.status(400).json({ success: false, message: 'Please provide full name, email, and shipping address.' });
    }

    // Verify stock and compute subtotal from actual DB prices
    let subtotal = 0;
    const verifiedItems = [];

    for (const item of items) {
      const product = await db.get('SELECT * FROM products WHERE id = ?', [item.productId]);
      if (!product) {
        return res.status(404).json({ success: false, message: `Product with ID ${item.productId} was not found.` });
      }

      if (product.stock < item.quantity) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for "${product.name}". Only ${product.stock} available.`
        });
      }

      const itemTotal = product.price * item.quantity;
      subtotal += itemTotal;

      verifiedItems.push({
        productId: product.id,
        name: product.name,
        image_url: product.image_url,
        price: product.price,
        quantity: item.quantity,
        total: itemTotal,
        currentStock: product.stock
      });
    }

    // Shipping calculation: Free over $50, else $9.99
    const shippingFee = subtotal >= 50.00 ? 0.00 : 9.99;
    const tax = Math.round(subtotal * 0.08 * 100) / 100; // 8% sales tax
    const totalAmount = Math.round((subtotal + shippingFee + tax) * 100) / 100;
    const orderNumber = generateOrderNumber();

    // 1. Insert order
    const orderResult = await db.run(
      `INSERT INTO orders 
       (order_number, user_id, customer_name, customer_email, customer_phone, shipping_address, payment_method, subtotal, shipping_fee, tax, total_amount, status, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'processing', ?)`,
      [
        orderNumber,
        userId,
        customer_name.trim(),
        customer_email.trim(),
        customer_phone ? customer_phone.trim() : null,
        shipping_address.trim(),
        payment_method || 'Credit Card',
        subtotal,
        shippingFee,
        tax,
        totalAmount,
        notes ? notes.trim() : null
      ]
    );

    const orderId = orderResult.lastID;

    // 2. Insert order items & reduce stock
    for (const vItem of verifiedItems) {
      await db.run(
        `INSERT INTO order_items (order_id, product_id, product_name, product_image, price, quantity, total)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [orderId, vItem.productId, vItem.name, vItem.image_url, vItem.price, vItem.quantity, vItem.total]
      );

      // Decrement stock
      await db.run(
        `UPDATE products SET stock = stock - ? WHERE id = ?`,
        [vItem.quantity, vItem.productId]
      );
    }

    // Retrieve created order with items
    const order = await db.get('SELECT * FROM orders WHERE id = ?', [orderId]);
    const orderItems = await db.all('SELECT * FROM order_items WHERE order_id = ?', [orderId]);

    res.status(201).json({
      success: true,
      message: 'Order placed successfully!',
      order: {
        ...order,
        items: orderItems
      }
    });
  } catch (error) {
    console.error('Error placing order:', error);
    res.status(500).json({ success: false, message: 'Server error while processing your order.' });
  }
});

// GET /api/orders/my (Customer view own orders)
router.get('/my', requireAuth, async (req, res) => {
  try {
    const orders = await db.all(
      `SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC`,
      [req.user.id]
    );

    // Attach items to each order
    for (const order of orders) {
      order.items = await db.all('SELECT * FROM order_items WHERE order_id = ?', [order.id]);
    }

    res.json({ success: true, orders });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to retrieve your orders.' });
  }
});

// GET /api/orders (Admin view all orders)
router.get('/', requireAdmin, async (req, res) => {
  try {
    const { status, search } = req.query;
    let query = `SELECT * FROM orders WHERE 1=1`;
    const params = [];

    if (status && status !== 'all') {
      query += ` AND status = ?`;
      params.push(status);
    }

    if (search && search.trim() !== '') {
      query += ` AND (order_number LIKE ? OR customer_name LIKE ? OR customer_email LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    query += ` ORDER BY created_at DESC`;

    const orders = await db.all(query, params);
    for (const order of orders) {
      order.items = await db.all('SELECT * FROM order_items WHERE order_id = ?', [order.id]);
    }

    res.json({ success: true, count: orders.length, orders });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to retrieve orders.' });
  }
});

// GET /api/orders/:id (Get single order by ID or order_number)
router.get('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    let order;

    if (isNaN(id)) {
      order = await db.get('SELECT * FROM orders WHERE order_number = ?', [id]);
    } else {
      order = await db.get('SELECT * FROM orders WHERE id = ?', [parseInt(id)]);
    }

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    // Check ownership if not admin
    if (order.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Unauthorized to view this order.' });
    }

    order.items = await db.all('SELECT * FROM order_items WHERE order_id = ?', [order.id]);
    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to retrieve order details.' });
  }
});

// PUT /api/orders/:id/status (Admin updates status)
router.put('/:id/status', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid order status value.' });
    }

    const order = await db.get('SELECT id FROM orders WHERE id = ?', [id]);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    await db.run('UPDATE orders SET status = ? WHERE id = ?', [status, id]);
    res.json({ success: true, message: `Order status updated to "${status}".` });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update order status.' });
  }
});

// PUT /api/orders/:id/cancel (Customer or Admin cancels order)
router.put('/:id/cancel', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const order = await db.get('SELECT * FROM orders WHERE id = ?', [id]);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    if (order.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Unauthorized to cancel this order.' });
    }

    if (order.status === 'delivered') {
      return res.status(400).json({ success: false, message: 'Delivered orders cannot be cancelled.' });
    }

    await db.run('UPDATE orders SET status = "cancelled" WHERE id = ?', [id]);

    // Restock items
    const items = await db.all('SELECT * FROM order_items WHERE order_id = ?', [id]);
    for (const it of items) {
      if (it.product_id) {
        await db.run('UPDATE products SET stock = stock + ? WHERE id = ?', [it.quantity, it.product_id]);
      }
    }

    res.json({ success: true, message: 'Order cancelled successfully and inventory restored.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to cancel order.' });
  }
});

module.exports = router;
