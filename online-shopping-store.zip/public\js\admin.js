// NovaMarket - Admin Portal Controller

let adminOrders = [];
let adminProducts = [];

document.addEventListener('DOMContentLoaded', async () => {
  const user = getUser();
  const token = getToken();

  if (!user || !token || user.role !== 'admin') {
    showToast('Unauthorized access. Admin privileges required.', 'error');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1000);
    return;
  }

  const nameEl = document.getElementById('admin-user-name');
  if (nameEl) nameEl.innerText = user.name;

  await loadAdminStats();
  await loadAdminOrders();
  await loadAdminProducts();

  // Search & filter listeners
  document.getElementById('admin-order-search')?.addEventListener('input', filterAdminOrders);
  document.getElementById('admin-order-status-filter')?.addEventListener('change', filterAdminOrders);
});

function switchAdminView(tabName) {
  document.querySelectorAll('.admin-nav-item').forEach(el => el.classList.remove('active'));
  document.getElementById(`tab-nav-${tabName}`)?.classList.add('active');

  const views = ['dashboard', 'orders', 'products'];
  views.forEach(v => {
    const el = document.getElementById(`view-${v}`);
    if (el) el.style.display = (v === tabName) ? 'block' : 'none';
  });
}

// 1. Load Stats
async function loadAdminStats() {
  const token = getToken();
  try {
    const res = await fetch('/api/admin/stats', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();

    if (res.ok && data.success && data.stats) {
      const s = data.stats;
      document.getElementById('kpi-sales').innerText = formatCurrency(s.totalRevenue);
      document.getElementById('kpi-orders-count').innerText = s.totalOrders;
      document.getElementById('kpi-products-count').innerText = s.totalProducts;
      document.getElementById('kpi-customers-count').innerText = s.totalCustomers;

      // Top selling products table
      const topTbody = document.getElementById('top-products-tbody');
      if (topTbody && s.topProducts) {
        topTbody.innerHTML = s.topProducts.map(p => `
          <tr>
            <td><strong>${p.product_name}</strong></td>
            <td>${p.units_sold} units</td>
            <td><strong>${formatCurrency(p.sales_revenue)}</strong></td>
          </tr>
        `).join('');
      }

      // Low stock warning banner
      const lowStockBox = document.getElementById('low-stock-box');
      if (lowStockBox && s.lowStock && s.lowStock.length > 0) {
        lowStockBox.style.display = 'block';
        document.getElementById('low-stock-list').innerHTML = s.lowStock.map(p => `
          <li><strong>${p.name}</strong> — Only ${p.stock} remaining in warehouse</li>
        `).join('');
      }
    }
  } catch (err) {
    console.error('Failed to load admin stats:', err);
  }
}

// 2. Load Orders
async function loadAdminOrders() {
  const token = getToken();
  const tbody = document.getElementById('admin-orders-tbody');
  if (!tbody) return;

  tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 25px;">Loading store orders...</td></tr>';

  try {
    const res = await fetch('/api/orders', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();

    if (res.ok && data.success) {
      adminOrders = data.orders;
      renderAdminOrdersTable(adminOrders);
    }
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--danger);">Failed to load orders.</td></tr>';
  }
}

function filterAdminOrders() {
  const search = document.getElementById('admin-order-search')?.value.toLowerCase() || '';
  const status = document.getElementById('admin-order-status-filter')?.value || 'all';

  let filtered = adminOrders;

  if (status !== 'all') {
    filtered = filtered.filter(o => o.status === status);
  }

  if (search.trim() !== '') {
    filtered = filtered.filter(o =>
      o.order_number.toLowerCase().includes(search) ||
      o.customer_name.toLowerCase().includes(search) ||
      o.customer_email.toLowerCase().includes(search)
    );
  }

  renderAdminOrdersTable(filtered);
}

function renderAdminOrdersTable(orders) {
  const tbody = document.getElementById('admin-orders-tbody');
  if (!tbody) return;

  if (orders.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 30px; color: var(--text-muted);">No matching orders found.</td></tr>';
    return;
  }

  tbody.innerHTML = orders.map(o => `
    <tr>
      <td>
        <strong>#${o.order_number}</strong>
        <div style="font-size: 12px; color: var(--text-muted);">${new Date(o.created_at).toLocaleDateString()}</div>
      </td>
      <td>
        <div><strong>${o.customer_name}</strong></div>
        <div style="font-size: 12px; color: var(--text-muted);">${o.customer_email}</div>
      </td>
      <td>
        <span style="font-size: 13px;">${(o.items || []).map(i => `${i.quantity}x ${i.product_name}`).join(', ')}</span>
      </td>
      <td><strong>${formatCurrency(o.total_amount)}</strong></td>
      <td>
        <select onchange="updateOrderStatus(${o.id}, this.value)" class="form-control" style="padding: 4px 8px; font-size: 12px; font-weight: 600; width: 130px;">
          <option value="processing" ${o.status === 'processing' ? 'selected' : ''}>Processing</option>
          <option value="shipped" ${o.status === 'shipped' ? 'selected' : ''}>Shipped</option>
          <option value="delivered" ${o.status === 'delivered' ? 'selected' : ''}>Delivered</option>
          <option value="cancelled" ${o.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
        </select>
      </td>
      <td>
        <span class="badge badge-${o.status}">${o.status}</span>
      </td>
    </tr>
  `).join('');
}

async function updateOrderStatus(orderId, newStatus) {
  const token = getToken();
  try {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status: newStatus })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast(data.message, 'success');
      await loadAdminOrders();
      await loadAdminStats();
    } else {
      showToast(data.message || 'Status update failed.', 'error');
    }
  } catch (err) {
    showToast('Failed to update status.', 'error');
  }
}

// 3. Load Products
async function loadAdminProducts() {
  const tbody = document.getElementById('admin-products-tbody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/products');
    const data = await res.json();

    if (data.success && data.products) {
      adminProducts = data.products;
      tbody.innerHTML = adminProducts.map(p => `
        <tr>
          <td><img src="${p.image_url}" style="width: 44px; height: 44px; object-fit: cover; border-radius: 6px;"></td>
          <td>
            <strong>${p.name}</strong>
            <div style="font-size: 12px; color: var(--text-muted);">${p.category_name}</div>
          </td>
          <td><strong>${formatCurrency(p.price)}</strong></td>
          <td>
            <span style="font-weight: 700; color: ${p.stock <= 10 ? 'var(--danger)' : 'var(--dark)'};">${p.stock} in stock</span>
          </td>
          <td>★ ${p.rating}</td>
          <td>
            <button onclick="deleteProduct(${p.id})" class="btn btn-secondary btn-sm" style="color: var(--danger); border-color: #fecaca;">Delete</button>
          </td>
        </tr>
      `).join('');
    }
  } catch (err) {
    console.error('Failed to load products:', err);
  }
}

function openAddProductModal() {
  document.getElementById('add-product-modal')?.classList.add('open');
}

function closeAddProductModal() {
  document.getElementById('add-product-modal')?.classList.remove('open');
}

async function handleCreateProduct(e) {
  e.preventDefault();
  const token = getToken();

  const name = document.getElementById('new-prod-name').value;
  const category_id = document.getElementById('new-prod-cat').value;
  const price = document.getElementById('new-prod-price').value;
  const original_price = document.getElementById('new-prod-orig-price').value;
  const stock = document.getElementById('new-prod-stock').value;
  const description = document.getElementById('new-prod-desc').value;
  const image_url = document.getElementById('new-prod-img').value;

  try {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ name, category_id, price, original_price, stock, description, image_url })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('Product added successfully!', 'success');
      closeAddProductModal();
      document.getElementById('add-product-form').reset();
      await loadAdminProducts();
      await loadAdminStats();
    } else {
      showToast(data.message || 'Failed to add product.', 'error');
    }
  } catch (err) {
    showToast('Failed to connect.', 'error');
  }
}

async function deleteProduct(id) {
  if (!confirm('Are you sure you want to delete this product?')) return;
  const token = getToken();

  try {
    const res = await fetch(`/api/products/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('Product deleted.', 'info');
      await loadAdminProducts();
      await loadAdminStats();
    }
  } catch (err) {
    showToast('Failed to delete.', 'error');
  }
}
