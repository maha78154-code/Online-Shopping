// NovaMarket - Main Client Utility & Cart Manager

const TOKEN_KEY = 'novamarket_token';
const USER_KEY = 'novamarket_user';
const CART_KEY = 'novamarket_cart';

// --- Toast Notifications ---
function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = '✓';
  if (type === 'error') icon = '✕';
  if (type === 'info') icon = 'ℹ';

  toast.innerHTML = `
    <div style="display: flex; align-items: center; gap: 8px;">
      <span style="font-weight: 700;">${icon}</span>
      <span>${message}</span>
    </div>
    <button style="background: none; border: none; font-size: 16px; cursor: pointer; color: inherit; opacity: 0.6;" onclick="this.parentElement.remove()">×</button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// --- Auth Helpers ---
function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

function getUser() {
  const u = localStorage.getItem(USER_KEY);
  return u ? JSON.parse(u) : null;
}

function setAuthSession(token, user) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

function clearAuthSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

function logout() {
  clearAuthSession();
  showToast('Logged out successfully.', 'info');
  setTimeout(() => {
    window.location.href = 'index.html';
  }, 400);
}

// --- Currency Formatter ---
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount || 0);
}

// --- Shopping Cart Management ---
function getCart() {
  const cartStr = localStorage.getItem(CART_KEY);
  return cartStr ? JSON.parse(cartStr) : [];
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartBadge();
}

function addToCart(product, quantity = 1) {
  const cart = getCart();
  const existing = cart.find(item => item.productId === product.id);

  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({
      productId: product.id,
      name: product.name,
      slug: product.slug,
      price: product.price,
      original_price: product.original_price,
      image_url: product.image_url,
      quantity: quantity
    });
  }

  saveCart(cart);
  showToast(`Added "${product.name}" to your cart! 🛍️`, 'success');
}

function updateCartQuantity(productId, quantity) {
  let cart = getCart();
  if (quantity <= 0) {
    cart = cart.filter(i => i.productId !== productId);
  } else {
    const item = cart.find(i => i.productId === productId);
    if (item) item.quantity = quantity;
  }
  saveCart(cart);
}

function removeFromCart(productId) {
  let cart = getCart();
  cart = cart.filter(i => i.productId !== productId);
  saveCart(cart);
  showToast('Item removed from cart.', 'info');
}

function clearCart() {
  localStorage.removeItem(CART_KEY);
  updateCartBadge();
}

function updateCartBadge() {
  const badge = document.getElementById('nav-cart-badge');
  if (!badge) return;

  const cart = getCart();
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  badge.innerText = totalCount;
  badge.style.display = totalCount > 0 ? 'flex' : 'none';
}

// --- Navbar State Manager ---
function updateNavbarAuth() {
  const container = document.getElementById('nav-user-actions');
  if (!container) return;

  const user = getUser();
  const token = getToken();

  if (user && token) {
    let adminBtn = '';
    if (user.role === 'admin') {
      adminBtn = `<a href="admin.html" class="btn btn-secondary btn-sm" style="font-size: 12px; border-color: var(--primary); color: var(--primary);">Admin Portal</a>`;
    }

    container.innerHTML = `
      ${adminBtn}
      <a href="my-orders.html" class="nav-action-btn">
        <span>📦</span> My Orders
      </a>
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="font-weight: 600; font-size: 14px; color: var(--dark);">${user.name.split(' ')[0]}</span>
        <button onclick="logout()" class="btn btn-secondary btn-sm" style="padding: 5px 10px;">Logout</button>
      </div>
    `;
  } else {
    container.innerHTML = `
      <a href="login.html" class="btn btn-primary btn-sm">Sign In / Register</a>
    `;
  }
}

// Global search bar handling
function initGlobalSearch() {
  const form = document.getElementById('global-search-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = document.getElementById('global-search-input')?.value.trim();
    if (query) {
      window.location.href = `products.html?search=${encodeURIComponent(query)}`;
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  updateCartBadge();
  updateNavbarAuth();
  initGlobalSearch();
});
