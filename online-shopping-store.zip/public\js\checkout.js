// NovaMarket - Checkout Controller

document.addEventListener('DOMContentLoaded', async () => {
  const cart = getCart();
  if (cart.length === 0) {
    showToast('Your cart is empty. Add items to checkout.', 'warning');
    setTimeout(() => {
      window.location.href = 'products.html';
    }, 1200);
    return;
  }

  // Pre-fill profile if logged in
  const user = getUser();
  if (user) {
    document.getElementById('checkout-name').value = user.name || '';
    document.getElementById('checkout-email').value = user.email || '';
    document.getElementById('checkout-phone').value = user.phone || '';
    if (user.address) {
      document.getElementById('checkout-address').value = user.address;
    }
  }

  renderCheckoutSummary(cart);

  const form = document.getElementById('checkout-form');
  if (form) {
    form.addEventListener('submit', handlePlaceOrder);
  }
});

function renderCheckoutSummary(cart) {
  const itemsContainer = document.getElementById('checkout-items-list');
  if (!itemsContainer) return;

  itemsContainer.innerHTML = cart.map(item => `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-size: 13px;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <span style="background: var(--bg-subtle); padding: 2px 7px; border-radius: var(--radius-sm); font-weight: 700;">${item.quantity}x</span>
        <span style="font-weight: 600; color: var(--dark);">${item.name}</span>
      </div>
      <strong>${formatCurrency(item.price * item.quantity)}</strong>
    </div>
  `).join('');

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = subtotal >= 50.00 ? 0.00 : 9.99;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  document.getElementById('co-subtotal').innerText = formatCurrency(subtotal);
  document.getElementById('co-shipping').innerText = shipping === 0 ? 'FREE' : formatCurrency(shipping);
  document.getElementById('co-tax').innerText = formatCurrency(tax);
  document.getElementById('co-total').innerText = formatCurrency(total);
}

async function handlePlaceOrder(e) {
  e.preventDefault();

  const user = getUser();
  const token = getToken();

  // If not logged in, prompt user
  if (!user || !token) {
    showToast('Please sign in or create an account to finalize your order.', 'info');
    setTimeout(() => {
      window.location.href = 'login.html?redirect=checkout.html';
    }, 1000);
    return;
  }

  const submitBtn = document.getElementById('place-order-btn');
  submitBtn.disabled = true;
  submitBtn.innerText = 'Processing Order...';

  const cart = getCart();
  const name = document.getElementById('checkout-name').value.trim();
  const email = document.getElementById('checkout-email').value.trim();
  const phone = document.getElementById('checkout-phone').value.trim();
  const address = document.getElementById('checkout-address').value.trim();
  const notes = document.getElementById('checkout-notes').value.trim();
  const paymentMethod = document.querySelector('input[name="payment-method"]:checked')?.value || 'Credit Card';

  const payload = {
    items: cart.map(i => ({ productId: i.productId, quantity: i.quantity })),
    customer_name: name,
    customer_email: email,
    customer_phone: phone,
    shipping_address: address,
    payment_method: paymentMethod,
    notes: notes
  };

  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (res.ok && data.success) {
      clearCart();
      showToast('Order confirmed! Redirecting...', 'success');
      setTimeout(() => {
        window.location.href = `order-confirmation.html?orderId=${data.order.order_number}`;
      }, 800);
    } else {
      showToast(data.message || 'Failed to place order.', 'error');
      submitBtn.disabled = false;
      submitBtn.innerText = 'Complete Purchase 🔒';
    }
  } catch (err) {
    showToast('Server communication error. Please try again.', 'error');
    submitBtn.disabled = false;
    submitBtn.innerText = 'Complete Purchase 🔒';
  }
}
