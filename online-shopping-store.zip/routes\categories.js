const express = require('express');
const router = express.Router();
const db = require('../database/db');

// GET /api/categories
router.get('/', async (req, res) => {
  try {
    const categories = await db.all(`
      SELECT c.*, COUNT(p.id) AS product_count 
      FROM categories c
      LEFT JOIN products p ON c.id = p.category_id
      GROUP BY c.id
      ORDER BY c.name ASC
    `);
    res.json({ success: true, categories });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch categories.' });
  }
});

module.exports = router;
