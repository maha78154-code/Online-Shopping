// NovaMarket - Shopping Cart Controller

let appliedDiscount = 0; // percentage, e.g. 0.20

document.addEventListener('DOMContentLoaded', () => {
  renderCart();

  const promoBtn = document.getElementById('apply-promo-btn');
  if (promoBtn) {
    promoBtn.addEventListener('click', applyPromoCode);
  }
});

function renderCart() {
  const container = document.getElementById('cart-items-container');
  const emptyState = document.getElementById('cart-empty-state');
  const cartContent = document.getElementById('cart-content-layout');

  const cart = getCart();

  if (cart.length === 0) {
    if (emptyState) emptyState.style.display = 'block';
    if (cartContent) cartContent.style.display = 'none';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';
  if (cartContent) cartContent.style.display = 'grid';

  if (!container) return;

  container.innerHTML = cart.map(item => `
    <div style="display: flex; align-items: center; justify-content: space-between; padding: 20px 0; border-bottom: 1px solid var(--border-light); gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; min-width: 260px;">
        <img src="${item.image_url}" alt="${item.name}" style="width: 75px; height: 75px; object-fit: cover; border-radius: var(--radius-sm); border: 1px solid var(--border);">
        <div>
          <h4 style="font-size: 15px; margin-bottom: 4px;">
            <a href="product-detail.html?id=${item.productId}">${item.name}</a>
          </h4>
          <div style="font-size: 13px; color: var(--text-muted);">${formatCurrency(item.price)} each</div>
        </div>
      </div>

      <!-- Quantity controls -->
      <div style="display: flex; align-items: center; border: 1px solid var(--border); border-radius: var(--radius-sm); background: #fff;">
        <button style="border: none; background: none; width: 32px; height: 32px; cursor: pointer;" onclick="changeQty(${item.productId}, -1)">−</button>
        <span style="padding: 0 12px; font-weight: 700; font-size: 14px;">${item.quantity}</span>
        <button style="border: none; background: none; width: 32px; height: 32px; cursor: pointer;" onclick="changeQty(${item.productId}, 1)">+</button>
      </div>

      <!-- Line total & remove -->
      <div style="display: flex; align-items: center; gap: 20px;">
        <div style="font-size: 16px; font-weight: 800; color: var(--dark); min-width: 80px; text-align: right;">
          ${formatCurrency(item.price * item.quantity)}
        </div>
        <button onclick="removeItem(${item.productId})" style="background: none; border: none; color: var(--text-light); cursor: pointer; font-size: 18px;" title="Remove item">
          🗑️
        </button>
      </div>
    </div>
  `).join('');

  updateCartTotals(cart);
}

function changeQty(productId, delta) {
  const cart = getCart();
  const item = cart.find(i => i.productId === productId);
  if (!item) return;

  const newQty = item.quantity + delta;
  updateCartQuantity(productId, newQty);
  renderCart();
}

function removeItem(productId) {
  removeFromCart(productId);
  renderCart();
}

function applyPromoCode() {
  const input = document.getElementById('promo-input');
  if (!input) return;

  const code = input.value.trim().toUpperCase();
  if (code === 'SAVE20') {
    appliedDiscount = 0.20;
    showToast('Promo code SAVE20 applied! 20% discount granted.', 'success');
  } else {
    appliedDiscount = 0;
    showToast('Invalid promo code. Try SAVE20.', 'error');
  }

  const cart = getCart();
  updateCartTotals(cart);
}

function updateCartTotals(cart) {
  let subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  let discountAmount = subtotal * appliedDiscount;
  let discountedSubtotal = subtotal - discountAmount;

  // Free shipping over $50
  let shipping = discountedSubtotal >= 50.00 ? 0.00 : (cart.length > 0 ? 9.99 : 0.00);
  let tax = discountedSubtotal * 0.08;
  let total = discountedSubtotal + shipping + tax;

  document.getElementById('cart-subtotal').innerText = formatCurrency(subtotal);

  const discountRow = document.getElementById('cart-discount-row');
  if (appliedDiscount > 0) {
    discountRow.style.display = 'flex';
    document.getElementById('cart-discount').innerText = `-${formatCurrency(discountAmount)}`;
  } else {
    discountRow.style.display = 'none';
  }

  document.getElementById('cart-shipping').innerText = shipping === 0 ? 'FREE' : formatCurrency(shipping);
  document.getElementById('cart-tax').innerText = formatCurrency(tax);
  document.getElementById('cart-total').innerText = formatCurrency(total);
}
