const express = require('express');
const path = require('path');
const cors = require('cors');
const config = require('./config');
const db = require('./database/db');

// Route Handlers
const authRoutes = require('./routes/auth');
const categoriesRoutes = require('./routes/categories');
const productsRoutes = require('./routes/products');
const ordersRoutes = require('./routes/orders');
const adminRoutes = require('./routes/admin');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend static files
app.use(express.static(path.join(__dirname, 'public')));

// Request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (req.originalUrl.startsWith('/api')) {
      console.log(`[${req.method}] ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
});

// API Routes Registration
app.use('/api/auth', authRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/admin', adminRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    store: 'NovaMarket E-Commerce Portal',
    timestamp: new Date().toISOString()
  });
});

// Fallback HTML router
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    const targetFile = path.join(__dirname, 'public', `${req.path}.html`);
    res.sendFile(targetFile, (err) => {
      if (err) {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
      }
    });
  } else {
    res.status(404).json({ success: false, message: 'API route not found' });
  }
});

// Start Server with auto-port fallback if in use
const listenOnPort = (port) => {
  const server = app.listen(port, () => {
    console.log('====================================================');
    console.log('   🛍️  NovaMarket E-Commerce Store Online 🛍️        ');
    console.log(`   Store URL:    http://localhost:${port}`);
    console.log(`   Admin Portal: http://localhost:${port}/admin.html`);
    console.log('   Customer:     customer@gmail.com / customer123');
    console.log('   Admin:        admin@store.com / admin123');
    console.log('====================================================');
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`⚠️ Port ${port} is occupied. Trying port ${port + 1}...`);
      listenOnPort(port + 1);
    } else {
      console.error('Server error:', err);
    }
  });

  process.on('SIGINT', () => {
    console.log('\nShutting down server gracefully...');
    server.close(() => {
      db.db.close(() => {
        console.log('Database connection closed.');
        process.exit(0);
      });
    });
  });
};

const startServer = async () => {
  try {
    await db.initDB();
    listenOnPort(config.PORT);
  } catch (error) {
    console.error('Failed to initialize database or start server:', error);
    process.exit(1);
  }
};

startServer();
