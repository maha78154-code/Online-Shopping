const path = require('path');
require('dotenv').config();

module.exports = {
  PORT: parseInt(process.env.PORT, 10) || 5050,
  JWT_SECRET: process.env.JWT_SECRET || 'novamarket_secret_key_default_2026',
  DB_PATH: process.env.DB_PATH || path.join(__dirname, 'database', 'store.sqlite')
};
