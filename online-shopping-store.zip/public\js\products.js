// NovaMarket - Product Catalog Controller

let currentFilters = {
  category: 'all',
  search: '',
  sort: 'featured',
  min_price: '',
  max_price: ''
};

document.addEventListener('DOMContentLoaded', async () => {
  // Parse URL query params
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('category')) currentFilters.category = urlParams.get('category');
  if (urlParams.get('search')) currentFilters.search = urlParams.get('search');
  if (urlParams.get('featured')) currentFilters.featured = '1';
  if (urlParams.get('trending')) currentFilters.trending = '1';

  // Set search input if populated
  const searchInput = document.getElementById('catalog-search-input');
  if (searchInput && currentFilters.search) {
    searchInput.value = currentFilters.search;
  }

  // Bind event listeners
  const sortSelect = document.getElementById('sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      currentFilters.sort = e.target.value;
      loadCatalogProducts();
    });
  }

  const applyPriceBtn = document.getElementById('apply-price-filter');
  if (applyPriceBtn) {
    applyPriceBtn.addEventListener('click', () => {
      currentFilters.min_price = document.getElementById('min-price-input')?.value || '';
      currentFilters.max_price = document.getElementById('max-price-input')?.value || '';
      loadCatalogProducts();
    });
  }

  await loadCategoriesFilter();
  await loadCatalogProducts();
});

async function loadCategoriesFilter() {
  const container = document.getElementById('category-filter-list');
  if (!container) return;

  try {
    const res = await fetch('/api/categories');
    const data = await res.json();

    if (data.success && data.categories) {
      let html = `
        <label class="filter-radio-label">
          <input type="radio" name="cat-filter" value="all" ${currentFilters.category === 'all' ? 'checked' : ''} onchange="onCategoryChange('all')">
          <span>All Categories</span>
        </label>
      `;

      html += data.categories.map(c => `
        <label class="filter-radio-label">
          <input type="radio" name="cat-filter" value="${c.slug}" ${currentFilters.category === c.slug ? 'checked' : ''} onchange="onCategoryChange('${c.slug}')">
          <span>${c.name} (${c.product_count})</span>
        </label>
      `).join('');

      container.innerHTML = html;
    }
  } catch (e) {
    console.error('Failed to load category filters:', e);
  }
}

function onCategoryChange(slug) {
  currentFilters.category = slug;
  loadCatalogProducts();
}

async function loadCatalogProducts() {
  const grid = document.getElementById('catalog-products-grid');
  const countLabel = document.getElementById('results-count');
  if (!grid) return;

  grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 60px 20px; color: var(--text-muted);">Loading products...</div>';

  try {
    const params = new URLSearchParams();
    if (currentFilters.category && currentFilters.category !== 'all') params.append('category', currentFilters.category);
    if (currentFilters.search) params.append('search', currentFilters.search);
    if (currentFilters.featured) params.append('featured', '1');
    if (currentFilters.trending) params.append('trending', '1');
    if (currentFilters.sort) params.append('sort', currentFilters.sort);
    if (currentFilters.min_price) params.append('min_price', currentFilters.min_price);
    if (currentFilters.max_price) params.append('max_price', currentFilters.max_price);

    const res = await fetch(`/api/products?${params.toString()}`);
    const data = await res.json();

    if (data.success && data.products) {
      if (countLabel) countLabel.innerText = `Showing ${data.products.length} products`;

      if (data.products.length === 0) {
        grid.innerHTML = `
          <div style="grid-column: 1/-1; text-align: center; padding: 70px 20px; background: #fff; border-radius: var(--radius-md); border: 1px solid var(--border);">
            <div style="font-size: 38px; margin-bottom: 12px;">🔍</div>
            <h3 style="font-size: 18px; margin-bottom: 8px;">No matching products found</h3>
            <p style="color: var(--text-muted); margin-bottom: 20px;">Try adjusting your search criteria or price filters.</p>
            <button class="btn btn-secondary btn-sm" onclick="resetFilters()">Reset All Filters</button>
          </div>
        `;
        return;
      }

      grid.innerHTML = data.products.map(p => {
        const discount = p.original_price ? Math.round(((p.original_price - p.price) / p.original_price) * 100) : 0;
        return `
          <div class="product-card">
            <div class="product-img-wrap">
              <a href="product-detail.html?id=${p.id}" style="width: 100%; height: 100%;">
                <img src="${p.image_url}" alt="${p.name}" class="product-img" loading="lazy">
              </a>
              ${discount > 0 ? `<span class="product-discount-badge">-${discount}%</span>` : ''}
              ${p.is_featured ? `<span class="product-badge-featured">Featured</span>` : ''}
            </div>
            <div class="product-body">
              <span class="product-category">${p.category_name || 'Item'}</span>
              <h3 class="product-title">
                <a href="product-detail.html?id=${p.id}">${p.name}</a>
              </h3>
              <div class="product-rating">
                <span class="product-stars">★ ${p.rating}</span>
                <span>(${p.reviews_count || 0})</span>
              </div>
              <div class="product-price-row">
                <span class="product-price">${formatCurrency(p.price)}</span>
                ${p.original_price ? `<span class="product-original-price">${formatCurrency(p.original_price)}</span>` : ''}
              </div>
              <button class="btn-add-cart" onclick='addToCart(${JSON.stringify({id: p.id, name: p.name, slug: p.slug, price: p.price, original_price: p.original_price, image_url: p.image_url})})'>
                🛒 Add to Cart
              </button>
            </div>
          </div>
        `;
      }).join('');
    }
  } catch (err) {
    grid.innerHTML = '<div style="grid-column: 1/-1; color: var(--danger); text-align: center;">Failed to load products.</div>';
  }
}

function resetFilters() {
  currentFilters = {
    category: 'all',
    search: '',
    sort: 'featured',
    min_price: '',
    max_price: ''
  };
  document.getElementById('catalog-search-input').value = '';
  document.getElementById('min-price-input').value = '';
  document.getElementById('max-price-input').value = '';
  loadCategoriesFilter();
  loadCatalogProducts();
}
