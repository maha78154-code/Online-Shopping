@echo off
title NovaMarket Online Shopping Store
echo ===================================================
echo     NovaMarket E-Commerce Online Store Portal       
echo ===================================================
echo.

cd /d "%~dp0"

echo [1/3] Checking Node.js installation...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found on your system PATH!
    echo Please install Node.js from https://nodejs.org/
    echo.
    pause
    exit /b 1
)

echo [2/3] Checking and installing dependencies...
if not exist "node_modules\" (
    echo Installing npm packages...
    call npm.cmd install
) else (
    echo Dependencies are already installed.
)

echo.
echo [3/3] Starting NovaMarket server...
echo ---------------------------------------------------
echo Store URL:    http://localhost:5050
echo Admin Portal: http://localhost:5050/admin.html
echo Customer:     customer@gmail.com / customer123
echo Admin:        admin@store.com / admin123
echo ---------------------------------------------------
echo.

call npm.cmd start
pause
