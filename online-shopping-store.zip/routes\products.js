const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAdmin, requireAuth, optionalAuth } = require('../middleware/auth');

// Helper to make URL-friendly slug
function makeSlug(text) {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-');
}

// GET /api/products
router.get('/', async (req, res) => {
  try {
    const { category, search, featured, trending, min_price, max_price, sort } = req.query;

    let query = `
      SELECT p.*, c.name AS category_name, c.slug AS category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (category && category !== 'all') {
      if (isNaN(category)) {
        query += ` AND c.slug = ?`;
        params.push(category);
      } else {
        query += ` AND p.category_id = ?`;
        params.push(parseInt(category));
      }
    }

    if (search && search.trim() !== '') {
      query += ` AND (p.name LIKE ? OR p.description LIKE ?)`;
      params.push(`%${search.trim()}%`, `%${search.trim()}%`);
    }

    if (featured === '1' || featured === 'true') {
      query += ` AND p.is_featured = 1`;
    }

    if (trending === '1' || trending === 'true') {
      query += ` AND p.is_trending = 1`;
    }

    if (min_price) {
      query += ` AND p.price >= ?`;
      params.push(parseFloat(min_price));
    }

    if (max_price) {
      query += ` AND p.price <= ?`;
      params.push(parseFloat(max_price));
    }

    // Sorting
    switch (sort) {
      case 'price_asc':
        query += ` ORDER BY p.price ASC`;
        break;
      case 'price_desc':
        query += ` ORDER BY p.price DESC`;
        break;
      case 'rating':
        query += ` ORDER BY p.rating DESC, p.reviews_count DESC`;
        break;
      case 'newest':
        query += ` ORDER BY p.created_at DESC`;
        break;
      default:
        query += ` ORDER BY p.is_featured DESC, p.is_trending DESC, p.id ASC`;
        break;
    }

    const products = await db.all(query, params);
    res.json({ success: true, count: products.length, products });
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve products.' });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    let product;

    if (isNaN(id)) {
      product = await db.get(
        `SELECT p.*, c.name AS category_name, c.slug AS category_slug 
         FROM products p 
         LEFT JOIN categories c ON p.category_id = c.id 
         WHERE p.slug = ?`,
        [id]
      );
    } else {
      product = await db.get(
        `SELECT p.*, c.name AS category_name, c.slug AS category_slug 
         FROM products p 
         LEFT JOIN categories c ON p.category_id = c.id 
         WHERE p.id = ?`,
        [parseInt(id)]
      );
    }

    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    // Fetch reviews for this product
    const reviews = await db.all(
      `SELECT * FROM reviews WHERE product_id = ? ORDER BY created_at DESC`,
      [product.id]
    );

    // Fetch 4 related products in the same category
    const relatedProducts = await db.all(
      `SELECT id, name, slug, price, original_price, rating, reviews_count, image_url 
       FROM products 
       WHERE category_id = ? AND id != ? 
       LIMIT 4`,
      [product.category_id, product.id]
    );

    res.json({
      success: true,
      product,
      reviews,
      relatedProducts
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to retrieve product details.' });
  }
});

// POST /api/products/:id/reviews (Customer submits review)
router.post('/:id/reviews', requireAuth, async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    const { rating, comment } = req.body;

    if (!rating || !comment) {
      return res.status(400).json({ success: false, message: 'Rating and comment are required.' });
    }

    await db.run(
      `INSERT INTO reviews (product_id, user_id, customer_name, rating, comment)
       VALUES (?, ?, ?, ?, ?)`,
      [productId, req.user.id, req.user.name, parseInt(rating), comment.trim()]
    );

    // Update product overall rating & review count
    const stats = await db.get(
      `SELECT AVG(rating) as avg_rating, COUNT(id) as count FROM reviews WHERE product_id = ?`,
      [productId]
    );

    await db.run(
      `UPDATE products SET rating = ?, reviews_count = ? WHERE id = ?`,
      [Math.round(stats.avg_rating * 10) / 10, stats.count, productId]
    );

    res.status(201).json({ success: true, message: 'Review submitted successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to submit review.' });
  }
});

// POST /api/products (Admin create)
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { category_id, name, description, price, original_price, stock, image_url, is_featured, is_trending } = req.body;

    if (!name || !price) {
      return res.status(400).json({ success: false, message: 'Product name and price are required.' });
    }

    const slug = makeSlug(name) + '-' + Date.now().toString().slice(-4);
    const defaultImg = image_url || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80';

    const result = await db.run(
      `INSERT INTO products 
       (category_id, name, slug, description, price, original_price, stock, image_url, is_featured, is_trending)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        category_id ? parseInt(category_id) : 1,
        name.trim(),
        slug,
        description || '',
        parseFloat(price),
        original_price ? parseFloat(original_price) : null,
        stock !== undefined ? parseInt(stock) : 50,
        defaultImg,
        is_featured ? 1 : 0,
        is_trending ? 1 : 0
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Product created successfully!',
      productId: result.lastID
    });
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ success: false, message: 'Failed to create product.' });
  }
});

// PUT /api/products/:id (Admin update)
router.put('/:id', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { category_id, name, description, price, original_price, stock, image_url, is_featured, is_trending } = req.body;

    const existing = await db.get('SELECT id FROM products WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    await db.run(
      `UPDATE products 
       SET category_id = ?, name = ?, description = ?, price = ?, original_price = ?, stock = ?, image_url = ?, is_featured = ?, is_trending = ?
       WHERE id = ?`,
      [
        parseInt(category_id),
        name.trim(),
        description,
        parseFloat(price),
        original_price ? parseFloat(original_price) : null,
        parseInt(stock),
        image_url,
        is_featured ? 1 : 0,
        is_trending ? 1 : 0,
        id
      ]
    );

    res.json({ success: true, message: 'Product updated successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update product.' });
  }
});

// DELETE /api/products/:id (Admin delete)
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await db.run('DELETE FROM products WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Product deleted successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to delete product.' });
  }
});

module.exports = router;
