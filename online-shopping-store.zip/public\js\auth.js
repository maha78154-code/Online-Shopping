// NovaMarket - Auth Controller

document.addEventListener('DOMContentLoaded', () => {
  const user = getUser();
  const token = getToken();

  // Redirect if already authenticated and browsing login/register
  if (user && token && (window.location.pathname.endsWith('login.html') || window.location.pathname.endsWith('register.html'))) {
    if (user.role === 'admin') {
      window.location.href = 'admin.html';
    } else {
      window.location.href = 'my-orders.html';
    }
    return;
  }

  // Handle Login
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerText;
      submitBtn.innerText = 'Signing in...';
      submitBtn.disabled = true;

      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;

      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (res.ok && data.success) {
          setAuthSession(data.token, data.user);
          showToast(`Welcome back, ${data.user.name}!`, 'success');

          setTimeout(() => {
            const params = new URLSearchParams(window.location.search);
            const redirect = params.get('redirect');

            if (redirect) {
              window.location.href = redirect;
            } else if (data.user.role === 'admin') {
              window.location.href = 'admin.html';
            } else {
              window.location.href = 'my-orders.html';
            }
          }, 600);
        } else {
          showToast(data.message || 'Login failed.', 'error');
          submitBtn.innerText = originalText;
          submitBtn.disabled = false;
        }
      } catch (err) {
        showToast('Server communication error.', 'error');
        submitBtn.innerText = originalText;
        submitBtn.disabled = false;
      }
    });
  }

  // Handle Registration
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerText;

      const name = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim();
      const phone = document.getElementById('reg-phone').value.trim();
      const address = document.getElementById('reg-address').value.trim();
      const password = document.getElementById('reg-password').value;
      const confirmPassword = document.getElementById('reg-confirm-password').value;

      if (password !== confirmPassword) {
        showToast('Passwords do not match.', 'error');
        return;
      }

      if (password.length < 6) {
        showToast('Password must be at least 6 characters.', 'error');
        return;
      }

      submitBtn.innerText = 'Creating Account...';
      submitBtn.disabled = true;

      try {
        const res = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, phone, address, password })
        });

        const data = await res.json();

        if (res.ok && data.success) {
          setAuthSession(data.token, data.user);
          showToast('Account created successfully! Welcome to NovaMarket.', 'success');

          setTimeout(() => {
            const params = new URLSearchParams(window.location.search);
            const redirect = params.get('redirect');
            window.location.href = redirect || 'products.html';
          }, 800);
        } else {
          showToast(data.message || 'Registration failed.', 'error');
          submitBtn.innerText = originalText;
          submitBtn.disabled = false;
        }
      } catch (err) {
        showToast('Network error.', 'error');
        submitBtn.innerText = originalText;
        submitBtn.disabled = false;
      }
    });
  }
});

function fillDemo(role) {
  const emailInput = document.getElementById('login-email');
  const passwordInput = document.getElementById('login-password');
  if (!emailInput || !passwordInput) return;

  if (role === 'admin') {
    emailInput.value = 'admin@store.com';
    passwordInput.value = 'admin123';
    showToast('Admin demo credentials filled!', 'info');
  } else {
    emailInput.value = 'customer@gmail.com';
    passwordInput.value = 'customer123';
    showToast('Customer demo credentials filled!', 'info');
  }
}
