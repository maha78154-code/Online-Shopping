const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');
const config = require('../config');

// Open or create SQLite database file
const dbPath = config.DB_PATH;
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening SQLite store database:', err.message);
  } else {
    console.log(`Connected to SQLite store database at: ${dbPath}`);
  }
});

// Helper functions for Promise-based queries
const run = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
};

const get = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
};

const all = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
};

// Initialize schema and seed default data
const initDB = async () => {
  try {
    await run('PRAGMA foreign_keys = ON');

    // 1. Users Table
    await run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        role TEXT DEFAULT 'customer',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 2. Categories Table
    await run(`
      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT,
        image_url TEXT
      )
    `);

    // 3. Products Table
    await run(`
      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        original_price REAL,
        stock INTEGER DEFAULT 50,
        rating REAL DEFAULT 4.8,
        reviews_count INTEGER DEFAULT 0,
        image_url TEXT,
        is_featured INTEGER DEFAULT 0,
        is_trending INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
      )
    `);

    // 4. Orders Table
    await run(`
      CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_number TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        customer_name TEXT NOT NULL,
        customer_email TEXT NOT NULL,
        customer_phone TEXT,
        shipping_address TEXT NOT NULL,
        payment_method TEXT DEFAULT 'Credit Card',
        subtotal REAL NOT NULL,
        shipping_fee REAL DEFAULT 0.00,
        tax REAL DEFAULT 0.00,
        total_amount REAL NOT NULL,
        status TEXT DEFAULT 'processing',
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
      )
    `);

    // 5. Order Items Table
    await run(`
      CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER,
        product_name TEXT NOT NULL,
        product_image TEXT,
        price REAL NOT NULL,
        quantity INTEGER NOT NULL,
        total REAL NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL
      )
    `);

    // 6. Reviews Table
    await run(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        user_id INTEGER,
        customer_name TEXT NOT NULL,
        rating INTEGER DEFAULT 5,
        comment TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
      )
    `);

    // Seed default data if users table is empty
    const userCount = await get('SELECT COUNT(*) as count FROM users');
    if (userCount.count === 0) {
      console.log('Seeding initial e-commerce data into SQLite database...');
      await seedDatabase();
    }
  } catch (error) {
    console.error('Error initializing store database:', error);
  }
};

const seedDatabase = async () => {
  const salt = await bcrypt.genSalt(10);
  const adminPassword = await bcrypt.hash('admin123', salt);
  const customerPassword = await bcrypt.hash('customer123', salt);

  // 1. Insert default admin and demo customer
  await run(
    `INSERT INTO users (name, email, password, phone, address, role) VALUES (?, ?, ?, ?, ?, ?)`,
    ['Store Administrator', 'admin@store.com', adminPassword, '+1 (555) 987-6543', '100 Market St, San Francisco, CA', 'admin']
  );

  const customerRes = await run(
    `INSERT INTO users (name, email, password, phone, address, role) VALUES (?, ?, ?, ?, ?, ?)`,
    ['Alex Morgan', 'customer@gmail.com', customerPassword, '+1 (555) 234-5678', '742 Evergreen Terrace, Springfield, OR 97477', 'customer']
  );
  const customerId = customerRes.lastID;

  // 2. Insert Categories
  const categories = [
    {
      name: 'Electronics & Audio',
      slug: 'electronics',
      description: 'Cutting-edge smart devices, premium headphones, and gadgets.',
      image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Fashion & Apparel',
      slug: 'fashion',
      description: 'Contemporary streetwear, minimal footwear, and elevated essentials.',
      image_url: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Home & Lifestyle',
      slug: 'home',
      description: 'Modern aesthetic decor, artisan ceramic drinkware, and ambient living.',
      image_url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Beauty & Wellness',
      slug: 'beauty',
      description: 'Organic botanical skincare, nourishing serums, and personal care.',
      image_url: 'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Watches & Accessories',
      slug: 'accessories',
      description: 'Precision chronographs, leather wallets, and timeless accents.',
      image_url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80'
    }
  ];

  for (const c of categories) {
    await run(
      `INSERT INTO categories (name, slug, description, image_url) VALUES (?, ?, ?, ?)`,
      [c.name, c.slug, c.description, c.image_url]
    );
  }

  // 3. Insert Products
  const products = [
    {
      category_id: 1,
      name: 'AcousticMax Pro Wireless ANC Headphones',
      slug: 'acousticmax-pro-wireless-headphones',
      description: 'Active hybrid noise-cancelling over-ear headphones with 45-hour battery life, high-resolution audio codecs, and plush memory foam ear cushions.',
      price: 199.99,
      original_price: 249.99,
      stock: 45,
      rating: 4.9,
      reviews_count: 128,
      image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
      is_featured: 1,
      is_trending: 1
    },
    {
      category_id: 1,
      name: 'SonicPulse Ultra Portable Bluetooth Speaker',
      slug: 'sonicpulse-ultra-portable-speaker',
      description: 'IP67 dust and waterproof wireless speaker with punchy 360-degree bass, 20-hour playback, and rugged outdoor strap.',
      price: 79.99,
      original_price: 99.99,
      stock: 60,
      rating: 4.8,
      reviews_count: 94,
      image_url: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=600&q=80',
      is_featured: 1,
      is_trending: 0
    },
    {
      category_id: 5,
      name: 'Apex Chrono Minimalist Sapphire Watch',
      slug: 'apex-chrono-minimalist-watch',
      description: 'Precision Japanese quartz movement encased in 316L brushed stainless steel with anti-reflective scratch-resistant sapphire crystal.',
      price: 149.00,
      original_price: 189.00,
      stock: 28,
      rating: 4.9,
      reviews_count: 67,
      image_url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80',
      is_featured: 1,
      is_trending: 1
    },
    {
      category_id: 2,
      name: 'Heritage Raw Denim Trucker Jacket',
      slug: 'heritage-raw-denim-trucker-jacket',
      description: 'Crafted from 100% heavyweight 14oz Japanese selvedge denim. Tailored relaxed fit with custom antiqued copper rivets.',
      price: 129.50,
      original_price: 159.00,
      stock: 35,
      rating: 4.7,
      reviews_count: 42,
      image_url: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&w=600&q=80',
      is_featured: 0,
      is_trending: 1
    },
    {
      category_id: 2,
      name: 'CloudStride Clean Leather Sneakers',
      slug: 'cloudstride-clean-leather-sneakers',
      description: 'Full-grain Italian calf leather sneakers with ergonomic cushioned insoles, vulcanized rubber cupsole, and subtle gold embossing.',
      price: 110.00,
      original_price: 135.00,
      stock: 50,
      rating: 4.8,
      reviews_count: 89,
      image_url: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=600&q=80',
      is_featured: 1,
      is_trending: 1
    },
    {
      category_id: 3,
      name: 'Artisan Ceramic Pour-Over Coffee Set',
      slug: 'artisan-ceramic-pourover-coffee-set',
      description: 'Handcrafted stoneware dripper with heat-resistant borosilicate glass carafe and natural beechwood collar for the ultimate morning brew ritual.',
      price: 48.00,
      original_price: 60.00,
      stock: 75,
      rating: 4.9,
      reviews_count: 53,
      image_url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80',
      is_featured: 1,
      is_trending: 0
    },
    {
      category_id: 3,
      name: 'Nordic Glow Minimalist Ambient Desk Lamp',
      slug: 'nordic-glow-minimalist-desk-lamp',
      description: 'Dimmable touch-sensitive LED architecture lamp with warm 2700K illumination, matte black aluminum neck, and weighted base.',
      price: 65.00,
      original_price: 85.00,
      stock: 40,
      rating: 4.8,
      reviews_count: 31,
      image_url: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=600&q=80',
      is_featured: 0,
      is_trending: 1
    },
    {
      category_id: 4,
      name: 'Botanical Radiance Vitamin C + Peptide Elixir',
      slug: 'botanical-radiance-vitamin-c-elixir',
      description: 'Concentrated 15% bioactive Vitamin C formulated with hyaluronic acid, ferulic acid, and cold-pressed jojoba for radiant, plump skin.',
      price: 42.00,
      original_price: 55.00,
      stock: 110,
      rating: 4.9,
      reviews_count: 145,
      image_url: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80',
      is_featured: 1,
      is_trending: 1
    },
    {
      category_id: 4,
      name: 'HydraSilk Nourishing Overnight Barrier Balm',
      slug: 'hydrasilk-nourishing-overnight-balm',
      description: 'Ceramide-infused night treatment that seals in moisture, calms redness, and repairs the lipid barrier while you sleep.',
      price: 36.50,
      original_price: 45.00,
      stock: 85,
      rating: 4.8,
      reviews_count: 76,
      image_url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80',
      is_featured: 0,
      is_trending: 0
    },
    {
      category_id: 5,
      name: 'Vault RFID-Blocking Full Grain Leather Wallet',
      slug: 'vault-rfid-leather-wallet',
      description: 'Slim bifold handcrafted from vegetable-tanned leather. Holds up to 10 cards and flat cash with military-grade RFID signal shielding.',
      price: 45.00,
      original_price: 58.00,
      stock: 65,
      rating: 4.7,
      reviews_count: 61,
      image_url: 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=600&q=80',
      is_featured: 0,
      is_trending: 1
    },
    {
      category_id: 1,
      name: 'MagCharge 3-in-1 Foldable Charging Station',
      slug: 'magcharge-3in1-foldable-charging-station',
      description: 'Fast wireless Qi charger for smartphone, smartwatch, and wireless earbuds simultaneously. Folds flat for compact travel.',
      price: 54.99,
      original_price: 69.99,
      stock: 90,
      rating: 4.8,
      reviews_count: 82,
      image_url: 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=600&q=80',
      is_featured: 1,
      is_trending: 1
    },
    {
      category_id: 2,
      name: 'Heavyweight Supima Cotton Everyday Crewneck',
      slug: 'heavyweight-supima-cotton-crewneck',
      description: 'Ultra-soft pre-shrunk combed American Supima cotton T-shirt. Reinforced ribbed collar and tailored drape that never loses shape.',
      price: 34.00,
      original_price: 42.00,
      stock: 120,
      rating: 4.9,
      reviews_count: 104,
      image_url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
      is_featured: 0,
      is_trending: 0
    }
  ];

  for (const p of products) {
    await run(
      `INSERT INTO products 
       (category_id, name, slug, description, price, original_price, stock, rating, reviews_count, image_url, is_featured, is_trending)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        p.category_id,
        p.name,
        p.slug,
        p.description,
        p.price,
        p.original_price,
        p.stock,
        p.rating,
        p.reviews_count,
        p.image_url,
        p.is_featured,
        p.is_trending
      ]
    );
  }

  // 4. Insert Sample Orders for Demo Customer
  const order1Res = await run(
    `INSERT INTO orders 
     (order_number, user_id, customer_name, customer_email, customer_phone, shipping_address, payment_method, subtotal, shipping_fee, tax, total_amount, status, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      'ORD-829104',
      customerId,
      'Alex Morgan',
      'customer@gmail.com',
      '+1 (555) 234-5678',
      '742 Evergreen Terrace, Springfield, OR 97477',
      'Credit Card (•••• 4242)',
      199.99,
      0.00,
      16.00,
      215.99,
      'delivered',
      'Leave at front door if not home.'
    ]
  );
  const order1Id = order1Res.lastID;

  await run(
    `INSERT INTO order_items (order_id, product_id, product_name, product_image, price, quantity, total)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      order1Id,
      1,
      'AcousticMax Pro Wireless ANC Headphones',
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
      199.99,
      1,
      199.99
    ]
  );

  const order2Res = await run(
    `INSERT INTO orders 
     (order_number, user_id, customer_name, customer_email, customer_phone, shipping_address, payment_method, subtotal, shipping_fee, tax, total_amount, status, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      'ORD-914022',
      customerId,
      'Alex Morgan',
      'customer@gmail.com',
      '+1 (555) 234-5678',
      '742 Evergreen Terrace, Springfield, OR 97477',
      'Credit Card (•••• 4242)',
      158.00,
      10.00,
      12.64,
      180.64,
      'processing',
      'Gift packaging requested.'
    ]
  );
  const order2Id = order2Res.lastID;

  await run(
    `INSERT INTO order_items (order_id, product_id, product_name, product_image, price, quantity, total)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      order2Id,
      5,
      'CloudStride Clean Leather Sneakers',
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=600&q=80',
      110.00,
      1,
      110.00
    ]
  );

  await run(
    `INSERT INTO order_items (order_id, product_id, product_name, product_image, price, quantity, total)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      order2Id,
      6,
      'Artisan Ceramic Pour-Over Coffee Set',
      'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80',
      48.00,
      1,
      48.00
    ]
  );

  // 5. Insert Sample Product Reviews
  await run(
    `INSERT INTO reviews (product_id, customer_name, rating, comment) VALUES (?, ?, ?, ?)`,
    [1, 'Jordan K.', 5, 'The noise cancellation is astounding. Battery lasts all week on a single charge!']
  );
  await run(
    `INSERT INTO reviews (product_id, customer_name, rating, comment) VALUES (?, ?, ?, ?)`,
    [1, 'Taylor S.', 5, 'Extremely comfortable for long flights. Audio resolution is crystal clear.']
  );
  await run(
    `INSERT INTO reviews (product_id, customer_name, rating, comment) VALUES (?, ?, ?, ?)`,
    [5, 'Casey R.', 5, 'Super clean aesthetic. Fits true to size and zero break-in period needed!']
  );

  console.log('Online Store database successfully seeded with users, products, categories, and orders.');
};

module.exports = {
  db,
  run,
  get,
  all,
  initDB
};
